class GitHub {
    open fun Hello(){
        println("Hello, Kotlin")
    }
    open fun Bye(){
        println("Bye, Kotlin")
    }
}